package pages;

import java.time.Duration;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class LoginPage {

    private WebDriver driver;

    private By usernameField = By.cssSelector("input[name='username']");
    private By passwordField = By.cssSelector("input[type='password']");
    private By signInButton = By.cssSelector("button[type='submit']");

    public LoginPage(WebDriver driver) {
        this.driver = driver;
    }

    public void login(String username, String password) {
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(15));
        
        // Fill Username
        WebElement userInput = wait.until(ExpectedConditions.visibilityOfElementLocated(usernameField));
        userInput.clear();
        triggerReactInputEvent(userInput, username);
        pauseExecution(1000);

        // Fill Password
        WebElement passInput = driver.findElement(passwordField);
        passInput.clear();
        triggerReactInputEvent(passInput, password);
        pauseExecution(1000);

        // Click Sign In
        WebElement btn = wait.until(ExpectedConditions.presenceOfElementLocated(signInButton));
        JavascriptExecutor js = (JavascriptExecutor) driver;
        
        js.executeScript("arguments[0].removeAttribute('disabled');", btn);
        js.executeScript("arguments[0].click();", btn);
        pauseExecution(3000);
    }

    private void triggerReactInputEvent(WebElement element, String value) {
        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript(
            "var element = arguments[0];" +
            "var value = arguments[1];" +
            "var nativeInputValueSetter = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value').set;" +
            "nativeInputValueSetter.call(element, value);" +
            "element.dispatchEvent(new Event('input', { bubbles: true }));" +
            "element.dispatchEvent(new Event('change', { bubbles: true }));",
            element, value
        );
    }

    private void pauseExecution(long milliseconds) {
        try {
            Thread.sleep(milliseconds);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }
}