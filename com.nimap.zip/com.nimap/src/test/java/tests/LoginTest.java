package tests;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import base.BaseTest;
import pages.DashboardPage;
import pages.LoginPage;

public class LoginTest extends BaseTest {

    @DataProvider(name = "timeSheetData")
    public Object[][] getTimeSheetData() {
        return new Object[][] {
            // Punch In Time, Punch Out Time, Reason, Attachment File Path (Blank rakha h taaki auto pdf ban ke upload ho)
            { "09:00", "18:00", "Official Claim Submission", "" }
        };
    }

    @Test(dataProvider = "timeSheetData")
    public void fullAutomatedTimeSheetTest(String inTime, String outTime, String reason, String filePath) {
        
        // 1. Login
        LoginPage loginPage = new LoginPage(driver);
        loginPage.login("prernamca21@gmail.com", "Prernasuraj");

        // 2. Complete Auto Fill, Attach File & Submit
        DashboardPage dashboardPage = new DashboardPage(driver);
        dashboardPage.fillAndSubmitTimeSheet(inTime, outTime, reason, filePath);

        pauseExecution(10000);
    }

    private void pauseExecution(long milliseconds) {
        try {
            Thread.sleep(milliseconds);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }
}