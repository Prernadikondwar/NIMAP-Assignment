package tests;

import org.testng.annotations.Test;

public class SmokeTest {

    @Test
    public void test() {

        System.out.println("TestNG is working!");

    }
}